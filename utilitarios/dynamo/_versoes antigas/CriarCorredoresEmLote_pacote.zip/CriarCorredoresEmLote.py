# -*- coding: utf-8 -*-
# =============================================================================
#  CRIACAO DE CORREDORES EM LOTE  -  Dynamo for Civil 3D (no Python Script)
# =============================================================================
#
#  ENTRADAS (portas do no Python Script, nessa ordem):
#
#   IN[0]  RODAR             (bool)   False = so simula e reporta, True = cria
#   IN[1]  MODO              (string) "auto"   -> greide vem do proprio alinhamento
#                                     "codigo" -> greide casado pelo codigo do nome
#   IN[2]  CORREDOR_UNICO    (bool)   True  = 1 corredor com N baselines
#                                     False = 1 corredor por rua
#   IN[3]  NOME_BASE         (string) ex.: "CORREDOR LOTEAMENTO"  (usado se unico)
#                                     ou prefixo, se um corredor por rua
#
#  CONVENCAO DE NOMES ESPERADA (modo "codigo"):
#     01 RUA SAO MIGUEL ALINHAMENTO
#     01 RUA SAO MIGUEL GREIDE
#     01 RUA SAO MIGUEL SECAO      (ou 01 SECAO TIPO, ou uma unica assembly p/ tudo)
#
#  O codigo e o primeiro numero do nome. "01", "1" e "001" sao tratados como iguais.
#  Acentos e caixa sao ignorados na leitura das palavras-chave.
# =============================================================================

import clr
import re
import unicodedata

clr.AddReference('AcMgd')
clr.AddReference('AcDbMgd')
clr.AddReference('AcCoreMgd')
clr.AddReference('AeccDbMgd')

from Autodesk.AutoCAD.ApplicationServices import Application
from Autodesk.AutoCAD.DatabaseServices import OpenMode
from Autodesk.Civil.ApplicationServices import CivilApplication
from Autodesk.Civil.DatabaseServices import ProfileType

# ------------------------------------------------------------------ entradas
RODAR          = IN[0] if len(IN) > 0 and IN[0] is not None else False
MODO           = (IN[1] if len(IN) > 1 and IN[1] else "auto").strip().lower()
CORREDOR_UNICO = IN[2] if len(IN) > 2 and IN[2] is not None else True
NOME_BASE      = (IN[3] if len(IN) > 3 and IN[3] else "CORREDOR").strip()

log = []
criados = []


# ------------------------------------------------------------------ utilidades
# compatibilidade IronPython 2.7  x  CPython3 (Dynamo 2.13+)
try:
    TEXTO = unicode
except NameError:
    TEXTO = str


def normaliza(txt):
    """Minusculas, sem acento, espacos colapsados. Para comparar palavras-chave."""
    if txt is None:
        return ""
    t = unicodedata.normalize('NFKD', TEXTO(txt))
    t = u"".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r'\s+', ' ', t).strip().lower()


def codigo(nome):
    """Extrai o primeiro numero do nome como chave. '01 Rua X' -> '1'. Sem numero -> None."""
    m = re.search(r'\d+', nome or "")
    return str(int(m.group(0))) if m else None


def papel(nome):
    """Classifica o objeto pelo nome: 'ali', 'gre', 'sec' ou None."""
    n = normaliza(nome)
    if re.search(r'\b(alinhamento|alinham|align|eixo|ali)\b', n):
        return 'ali'
    if re.search(r'\b(greide|gre|perfil de projeto|projeto|pv)\b', n):
        return 'gre'
    if re.search(r'\b(secao|sec|secao tipo|tipo|assembly|montagem)\b', n):
        return 'sec'
    return None


def rotulo(nome):
    """Nome limpo para compor o nome do corredor: tira codigo e palavra-chave."""
    n = re.sub(r'^\s*\d+\s*[-_.)]?\s*', '', nome or "")
    n = re.sub(r'(?i)\s*(alinhamento|alinham|align|eixo|greide|secao|seção|sec|tipo)\s*$', '', n)
    return n.strip() or (nome or "").strip()


# ------------------------------------------------------------------ documento
adoc = Application.DocumentManager.MdiActiveDocument
civdoc = CivilApplication.ActiveDocument

with adoc.LockDocument():
    db = adoc.Database
    with db.TransactionManager.StartTransaction() as t:

        # -------------------------------------------------- coleta alinhamentos
        alis = []   # (codigo, nome, ObjectId, objeto)
        for aid in civdoc.GetAlignmentIds():
            a = t.GetObject(aid, OpenMode.ForRead)
            alis.append((codigo(a.Name), a.Name, aid, a))

        # -------------------------------------------------- coleta assemblies
        asms = {}          # codigo -> ObjectId
        asms_todas = []    # (nome, ObjectId)
        for sid in civdoc.GetAssemblyIds():
            s = t.GetObject(sid, OpenMode.ForRead)
            asms_todas.append((s.Name, sid))
            c = codigo(s.Name)
            if c and c not in asms:
                asms[c] = sid

        assembly_unica = asms_todas[0][1] if len(asms_todas) == 1 else None

        if not alis:
            log.append(u"Nenhum alinhamento encontrado no desenho.")

        # -------------------------------------------------- monta os pares
        # cada item: dict com nome da rua, alinhamento, greide e assembly
        pares = []

        for cod, nome_ali, aid, a in alis:

            # ignora alinhamentos que claramente nao sao eixo de rua
            if MODO == "codigo" and papel(nome_ali) not in ('ali', None):
                continue

            # ---------------- GREIDE
            prof_id = None
            prof_nome = None

            # 1) sempre olha primeiro os perfis do proprio alinhamento
            candidatos = []
            for pid in a.GetProfileIds():
                p = t.GetObject(pid, OpenMode.ForRead)
                candidatos.append((p.Name, pid, p.ProfileType))

            fg = [c for c in candidatos if c[2] == ProfileType.FG]

            if MODO == "codigo" and cod:
                # casa pelo codigo + palavra "greide" dentro dos perfis do alinhamento
                match = [c for c in candidatos
                         if codigo(c[0]) == cod and papel(c[0]) == 'gre']
                if not match:
                    match = [c for c in candidatos if papel(c[0]) == 'gre']
                if match:
                    prof_nome, prof_id = match[0][0], match[0][1]

            if prof_id is None:
                # modo auto (ou fallback): pega o perfil de projeto (FG)
                if len(fg) == 1:
                    prof_nome, prof_id = fg[0][0], fg[0][1]
                elif len(fg) > 1:
                    pref = [c for c in fg if papel(c[0]) == 'gre'] or fg
                    prof_nome, prof_id = pref[0][0], pref[0][1]
                    log.append(u"AVISO  %s: %d greides FG, usando '%s'."
                               % (nome_ali, len(fg), prof_nome))

            if prof_id is None:
                log.append(u"PULOU  %s: sem greide (perfil FG) definido." % nome_ali)
                continue

            # ---------------- SECAO TIPO
            asm_id = None
            if cod and cod in asms:
                asm_id = asms[cod]
            elif assembly_unica is not None:
                asm_id = assembly_unica
            else:
                # tenta casar por nome da rua
                alvo = normaliza(rotulo(nome_ali))
                for nm, sid in asms_todas:
                    if alvo and alvo in normaliza(nm):
                        asm_id = sid
                        break

            if asm_id is None:
                log.append(u"PULOU  %s: nenhuma secao tipo correspondente "
                           u"(codigo '%s')." % (nome_ali, cod))
                continue

            pares.append({
                'cod': cod or '--',
                'rua': rotulo(nome_ali),
                'ali_nome': nome_ali,
                'ali_id': aid,
                'gre_nome': prof_nome,
                'gre_id': prof_id,
                'asm_id': asm_id,
                'ini': a.StartingStation,
                'fim': a.EndingStation
            })

        # -------------------------------------------------- relatorio previo
        log.insert(0, u"=== %d rua(s) prontas para virar corredor ===" % len(pares))
        for p in pares:
            log.append(u"  [%s] %s  |  greide: %s  |  est %.2f a %.2f"
                       % (p['cod'], p['rua'], p['gre_nome'], p['ini'], p['fim']))

        # -------------------------------------------------- criacao
        if RODAR and pares:

            existentes = set()
            for cid in civdoc.CorridorCollection:
                try:
                    existentes.add(t.GetObject(cid, OpenMode.ForRead).Name)
                except:
                    pass

            def novo_nome(base):
                nome, i = base, 1
                while nome in existentes:
                    i += 1
                    nome = u"%s (%d)" % (base, i)
                existentes.add(nome)
                return nome

            def add_region(baseline, nome_reg, asm_id, ini, fim):
                """Cobre as variacoes de assinatura entre versoes do Civil 3D."""
                try:
                    return baseline.BaselineRegions.Add(nome_reg, asm_id, ini, fim)
                except:
                    return baseline.BaselineRegions.Add(nome_reg, asm_id)

            if CORREDOR_UNICO:
                nome_corr = novo_nome(NOME_BASE)
                cid = civdoc.CorridorCollection.Add(nome_corr)
                corr = t.GetObject(cid, OpenMode.ForWrite)

                for p in pares:
                    bl_nome = u"BL %s %s" % (p['cod'], p['rua'])
                    bl = corr.Baselines.Add(bl_nome, p['ali_id'], p['gre_id'])
                    add_region(bl, u"RG %s %s" % (p['cod'], p['rua']),
                               p['asm_id'], p['ini'], p['fim'])

                corr.Rebuild()
                criados.append(nome_corr)
                log.append(u"OK  corredor unico '%s' com %d baselines."
                           % (nome_corr, len(pares)))

            else:
                for p in pares:
                    nome_corr = novo_nome(u"%s %s %s"
                                          % (NOME_BASE, p['cod'], p['rua']))
                    cid = civdoc.CorridorCollection.Add(nome_corr)
                    corr = t.GetObject(cid, OpenMode.ForWrite)

                    bl = corr.Baselines.Add(u"BL %s" % p['rua'],
                                            p['ali_id'], p['gre_id'])
                    add_region(bl, u"RG %s" % p['rua'],
                               p['asm_id'], p['ini'], p['fim'])

                    corr.Rebuild()
                    criados.append(nome_corr)
                    log.append(u"OK  %s" % nome_corr)

        elif not RODAR:
            log.append(u"--- MODO SIMULACAO: ligue RODAR para criar de fato. ---")

        t.Commit()

OUT = log
